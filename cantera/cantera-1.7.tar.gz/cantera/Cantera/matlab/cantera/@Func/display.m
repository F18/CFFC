function d = display(a)
% DISPLAY - 
%
disp(' ');
disp([inputname(1),' = '])
disp(' ');
disp(['   ' char(a)])
disp(' ');

