function r = times(a,b)
% TIMES - 
%   
r = Func('prod',a,b);

