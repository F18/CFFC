function r = rdivide(a,b)
% RDIVIDE - 
%   
r = Func('ratio',a,b);

