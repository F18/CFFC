function n = speciesNames(a)
n = speciesName(a,1:nSpecies(a));
