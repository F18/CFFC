function n = speciesIndex(self, k, p)
% SPECIESINDEX - index of species with name 'name'
%   
n = mixturemethods(23, mix_hndl(self), k, p);

