function n = temperature(self)
% TEMPERATURE - temperature (K)
%   
n = mixturemethods(25, mix_hndl(self));

