function setPressure(self, P)
% SETPRESSURE - set the mixture pressure (Pa)
%   
mixturemethods(6, mix_hndl(self), P);


