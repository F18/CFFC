function setTemperature(self, T)
% SETTEMPERATURE - set the mixture temperature
%   
mixturemethods(5, mix_hndl(self), T);


