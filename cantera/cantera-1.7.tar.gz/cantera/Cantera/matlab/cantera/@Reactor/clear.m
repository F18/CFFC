function clear(r)
% CLEAR - 
%   
reactormethods(2, reactor_hndl(r));

