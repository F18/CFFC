function setInitialTime(r, t0)
% SETINITIALTIME - set the initial time. Deprecated.
%   
reactormethods(5, reactor_hndl(r), t0);

