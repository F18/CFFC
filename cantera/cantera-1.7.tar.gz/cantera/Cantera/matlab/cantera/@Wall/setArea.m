function setArea(w, a)
% SETAREA - 
%   
wallmethods(5, wall_hndl(w), a);

