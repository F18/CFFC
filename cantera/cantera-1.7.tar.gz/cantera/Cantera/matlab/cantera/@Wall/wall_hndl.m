function i = wall_hndl(w)
% WALL_HNDL - 
%   
i = w.index;