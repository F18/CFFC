function ok = ready(w)
% READY - 
%   
ok = wallmethods(11, wall_hndl(w));

