function setThermalResistance(w, r)
% SETTHERMALRESISTANCE - 
%   
wallmethods(6, wall_hndl(w), r)

