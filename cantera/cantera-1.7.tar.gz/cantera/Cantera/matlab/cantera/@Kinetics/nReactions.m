function n = nReactions(a)
% NREACTIONS -  Number of reactions.
%
n = kinetics_get(a.id,1,0);

