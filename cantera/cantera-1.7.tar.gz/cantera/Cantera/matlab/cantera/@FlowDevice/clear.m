function clear(f)
% CLEAR - 
%   
flowdevicemethods(1, f.index)
