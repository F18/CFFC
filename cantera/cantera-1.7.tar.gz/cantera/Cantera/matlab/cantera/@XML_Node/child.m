function v = child(x, loc)

id = ctmethods(10, 6, x.id, loc);
v = XML_Node('', '', id);


