function n = nComponents(d)
n = domain_methods(d.dom_id, 11)
