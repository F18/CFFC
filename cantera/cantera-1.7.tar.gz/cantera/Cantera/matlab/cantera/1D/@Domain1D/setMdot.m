function d = setMdot(d, mdot)
% SETMDOT - 
%   
domain_methods(d.dom_id, 60, mdot);
