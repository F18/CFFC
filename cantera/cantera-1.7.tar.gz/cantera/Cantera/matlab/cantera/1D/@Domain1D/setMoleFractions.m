function d = setMoleFractions(d, x)
% SETMOLEFRACTIONS - 
%   
domain_methods(d.dom_id, 62, x);
