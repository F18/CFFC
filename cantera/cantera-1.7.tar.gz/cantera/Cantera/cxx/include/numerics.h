#ifndef CT_NUM_H_INCL
#define CT_NUM_H_INCL

#include "kernel/DenseMatrix.h"
#include "kernel/BandMatrix.h"

#endif
