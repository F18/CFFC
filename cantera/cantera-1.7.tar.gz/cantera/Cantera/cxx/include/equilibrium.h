/**
 * @file equilibrium.h
 * cxx layer - Header file providing support for chemical equilibrium calculations
 *    (see \ref equilfunctions)
 */
/*
 * $Id: equilibrium.h,v 1.7 2007/03/23 15:09:17 hkmoffa Exp $
 */
#ifndef CT_EQUIL_INCL
#define CT_EQUIL_INCL
#include "kernel/equil.h"
#include "kernel/ChemEquil.h"
#include "kernel/MultiPhaseEquil.h"
#endif
  

