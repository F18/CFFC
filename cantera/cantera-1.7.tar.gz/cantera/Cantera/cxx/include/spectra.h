#ifndef CT_SPECTRA_H_INCL
#define CT_SECTRA_H_INCL

#include "kernel/LineBroadener.h"
#include "kernel/rotor.h"
//#include "kernel/AbsorptionLine.h"

#endif
