#ifndef CT_RAD_H_INCL
#define CT_RAD_H_INCL

#include "kernel/rotor.h"
#include "kernel/LineBroadener.h"
//#include "kernel/AbsorptionLine.h"

#endif
