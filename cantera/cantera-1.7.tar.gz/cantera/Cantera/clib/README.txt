
This directory contains code that implements C-callable functions that
can be used to create and use Cantera objects from languages other
than C++. It is used by both the Python and Matlab interface packages.
