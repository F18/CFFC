
This directory contains the source for Cantera and its various
language interfaces.

clib    -  the library of C-callable functions used by the Python and
              Matlab interfaces.
cxx     -  files that are only required for C++ application programs.
matlab  -  the Cantera Matlab toolbox
python  -  the Cantera Python package
src     -  the Cantera kernel, used by Cantera in all its forms

