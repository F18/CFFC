function n = nElements(self)
% NELEMENTS - number of elements
%   
n = mixturemethods(21, mix_hndl(self));

