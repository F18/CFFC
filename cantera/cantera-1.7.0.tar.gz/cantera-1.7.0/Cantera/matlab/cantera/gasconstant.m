function r = gasconstant
% GASCONSTANT   The universal gas constant in J/kmol-K.
r = 8314.0;
