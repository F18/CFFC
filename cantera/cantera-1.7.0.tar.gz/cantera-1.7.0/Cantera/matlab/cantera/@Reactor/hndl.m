function i = hndl(r)
i = r.index;
