function i = hndl(k)
i = k.id;
