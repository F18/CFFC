function t = time(r)
% TIME - current value of the time.
%   
t = reactornetmethods(22, reactornet_hndl(r));

