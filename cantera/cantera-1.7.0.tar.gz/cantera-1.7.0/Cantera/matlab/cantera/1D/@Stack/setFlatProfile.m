function setFlatProfile(s, n, comp, v)
% SETFLATPROFILE - 
%   
stack_methods(s.stack_id, 102, n, comp, v);

