function d = setTemperature(d, t)
% SETTEMPERATURE - Set the temperature [K].
%   
domain_methods(d.dom_id, 61, t);
