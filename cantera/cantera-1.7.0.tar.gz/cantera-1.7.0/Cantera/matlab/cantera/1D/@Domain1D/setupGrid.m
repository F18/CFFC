function d = setupGrid(d, grid)
% SETUPGRID - 
%   
domain_methods(d.dom_id, 53, grid);

