function setHeatTransferCoeff(w, u)
% SETHEATTRANSFERCOEFF - 
%   
wallmethods(7, wall_hndl(w), u);

