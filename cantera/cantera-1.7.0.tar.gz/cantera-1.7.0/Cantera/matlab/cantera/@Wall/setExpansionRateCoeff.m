function setExpansionRateCoeff(w, k)
% SETEXPANSIONRATECOEFF - 
%   
wallmethods(9, wall_hndl(w), k);

