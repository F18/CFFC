function t = temperature(p)
% TEMPERATURE - temperature [K].
t = phase_get(p.tp_id,1);
