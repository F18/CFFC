/*
 * $Id: kinetics.h,v 1.3 2006/04/30 19:56:06 hkmoffa Exp $
 */
#ifndef CXX_INCL_KINETICS
#define CXX_INCL_KINETICS

#include "kernel/Kinetics.h"
#include "kernel/InterfaceKinetics.h"
#include "kernel/KineticsFactory.h"

#endif
